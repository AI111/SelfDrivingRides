import {readData, RidesData} from "./DataParser";
import {Car} from "./Car";

export class DriveSimulation{
    private inputData: RidesData;
    constructor(private inputFileName: string){
        this.inputData = readData(inputFileName);
        this.initSimulation();
    }
    private fleet: Array<Car>
    public writeOutput(): string {
        return this.fleet.map((car) => `${car.finishedRides.length} ${car.finishedRides.join(' ')}`).join('\n');
    }
    private initSimulation() {
        this.fleet = new Array(this.inputData.F);
        // this.fleet.fill(new Car());
        for( let i =0; i < this.fleet.length; i++) {
            this.fleet[i] = new Car(i);
        }

        for (let step = 0; step < this.inputData.T; step ++) {
            this.tick(step);
        }
        console.log(this.inputData);

    }
    private tick(step: number): void {
        for (let i = 0; i < this.fleet.length; i++){
            if(this.fleet[i].state === "idle"){
                // magic
                const  ride = this.inputData.rides.pop();
                if(!ride) continue;
                this.fleet[i].setRide(ride);
            }
            this.fleet[i].tick(step);
        }
        // console.log(` STEP: ${step} ${this.fleet.map((car) => car.toString())}`);
    }

}